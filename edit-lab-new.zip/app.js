/* The Edit Lab — منطق الواجهة.
   لا تحتاج تعديل هذا الملف. البيانات تأتي من settings.js و products.js */
(function () {
  "use strict";
  var S = window.SITE || {};
  var C = S.contact || {};
  var ALL = Array.isArray(window.PRODUCTS) ? window.PRODUCTS : [];
  var CUR = S.currencyLabel || "دج";
  var page = document.body.getAttribute("data-page") || "";

  /* ---------- أدوات ---------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function rich(t) { return esc(t).replace(/[A-Za-z][A-Za-z0-9 ]*[A-Za-z0-9]/g, "<bdi>$&</bdi>"); }
  function str(v) { return v == null ? "" : String(v).trim(); }
  function money(n) { return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, " "); }
  function priceHtml(n, big) { return '<span class="price' + (big ? " price-lg" : "") + '" dir="ltr">' + money(n) + "<small>" + esc(CUR) + "</small></span>"; }
  function httpUrl(u) { u = str(u); return /^https?:\/\//i.test(u) ? u : ""; }
  function visible() { return ALL.filter(function (p) { return p.status !== "hidden"; }); }
  function byId(id) { for (var i = 0; i < ALL.length; i++) if (ALL[i].id === id) return ALL[i]; return null; }
  function typeLabel(t) { return t === "audio" ? "AUDIO" : t === "video" ? "VIDEO" : t === "bundle" ? "BUNDLE" : ""; }
  function statusTag(p) {
    if (p.status === "soon") return '<span class="tag tag-soft">قريبًا</span>';
    if (p.status === "paused") return '<span class="tag tag-off">غير متوفر حاليًا</span>';
    return "";
  }

  /* ---------- قنوات التواصل ---------- */
  function channels(msg) {
    var list = [], wa = str(C.whatsapp).replace(/\D/g, ""), tg = str(C.telegram).replace(/^@/, ""), fb = httpUrl(C.facebook), ig = httpUrl(C.instagram);
    if (wa) list.push({ id: "whatsapp", label: "واتساب", hint: "+" + wa, url: "https://wa.me/" + wa + (msg ? "?text=" + encodeURIComponent(msg) : "") });
    if (tg) list.push({ id: "telegram", label: "تيليغرام", hint: "@" + tg, url: "https://t.me/" + encodeURIComponent(tg) });
    if (fb) list.push({ id: "facebook", label: "فيسبوك", hint: "Facebook", url: fb });
    if (ig) list.push({ id: "instagram", label: "إنستغرام", hint: "Instagram", url: ig });
    return list;
  }
  function mainChannel(msg) {
    var l = channels(msg);
    for (var i = 0; i < l.length; i++) if (l[i].id === S.preferredChannel) return l[i];
    return l[0] || null;
  }
  function orderMessage(p) {
    return "مرحبًا، أريد طلب المنتج: " + p.name + " (" + money(p.price) + " " + CUR + "). أرجو توضيح طريقة الدفع والتسليم.";
  }

  /* ---------- الرأس والتذييل ---------- */
  function renderChrome() {
    function nav(href, label, id) { return '<a href="' + href + '"' + (page === id ? ' aria-current="page"' : "") + ">" + label + "</a>"; }
    var h =
      '<a class="skip" href="#main">تخطَّ إلى المحتوى</a>' +
      '<header class="site-header"><div class="container header-inner">' +
      '<a class="logo" href="index.html" aria-label="' + esc(S.storeName) + '"><span class="logo-mark" aria-hidden="true"></span><span>' + esc(S.storeName) + "</span></a>" +
      '<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="nav" aria-label="القائمة"><span></span><span></span><span></span></button>' +
      '<nav id="nav" class="nav" aria-label="التنقل الرئيسي">' +
      nav("index.html", "الرئيسية", "home") + nav("products.html", "المنتجات", "products") + nav("faq.html", "الأسئلة الشائعة", "faq") + nav("contact.html", "تواصل معنا", "contact") +
      "</nav></div></header>";
    var ch = channels("");
    var links = ch.length
      ? ch.map(function (c) { return '<li><a href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer">' + c.label + "</a></li>"; }).join("")
      : '<li class="dim">لم تُضبط روابط التواصل بعد.</li>';
    if (str(C.email)) links += '<li><a href="mailto:' + esc(str(C.email)) + '" dir="ltr">' + esc(str(C.email)) + "</a></li>";
    var f =
      '<footer class="site-footer"><div class="container footer-grid">' +
      '<div><div class="logo"><span class="logo-mark" aria-hidden="true"></span><span>' + esc(S.storeName) + '</span></div><p>منتجات رقمية تُطلب بالتواصل المباشر مع البائع. الأسعار بالدينار الجزائري.</p></div>' +
      '<div><h3>الموقع</h3><ul><li><a href="index.html">الرئيسية</a></li><li><a href="products.html">المنتجات</a></li><li><a href="faq.html">الأسئلة الشائعة</a></li><li><a href="contact.html">تواصل معنا</a></li></ul></div>' +
      '<div><h3>السياسات</h3><ul><li><a href="terms.html">شروط الاستخدام</a></li><li><a href="privacy.html">سياسة الخصوصية</a></li><li><a href="refund.html">سياسة الاسترجاع</a></li></ul></div>' +
      "<div><h3>التواصل</h3><ul>" + links + "</ul></div></div>" +
      '<div class="container footer-bottom">© ' + new Date().getFullYear() + " " + esc(S.storeName) + "</div></footer>";
    var hh = document.getElementById("site-header"), ff = document.getElementById("site-footer");
    if (hh) hh.innerHTML = h;
    if (ff) ff.innerHTML = f;
    var b = document.querySelector(".nav-toggle"), n = document.getElementById("nav");
    if (b && n) b.addEventListener("click", function () { var o = n.classList.toggle("open"); b.setAttribute("aria-expanded", o ? "true" : "false"); });
  }

  /* ---------- بطاقة منتج ---------- */
  function card(p) {
    var url = "product.html?id=" + encodeURIComponent(p.id);
    return '<article class="card"><a class="card-cover" href="' + url + '" tabindex="-1" aria-hidden="true"><img src="' + esc(p.cover) + '" alt="" loading="lazy" width="800" height="500"></a>' +
      '<div class="card-body"><div class="tags"><span class="tag">' + typeLabel(p.type) + "</span>" + (p.categoryLabel ? '<span class="tag tag-soft">' + esc(p.categoryLabel) + "</span>" : "") + statusTag(p) + "</div>" +
      '<h3 class="card-title" dir="auto"><a href="' + url + '">' + esc(p.name) + "</a></h3>" +
      '<p class="card-desc">' + rich(p.tagline || p.description) + "</p>" +
      '<div class="card-foot">' + priceHtml(p.price) + '<a class="btn btn-primary btn-sm" href="' + url + '">عرض التفاصيل</a></div></div></article>';
  }

  function renderHome() {
    var el = document.getElementById("featured"); if (!el) return;
    var items = visible().filter(function (p) { return p.featured; });
    el.innerHTML = items.length ? items.map(card).join("") : '<p class="empty">لا توجد منتجات معروضة حاليًا.</p>';
  }

  function renderProducts() {
    var grid = document.getElementById("products-grid"), bar = document.getElementById("filters"); if (!grid) return;
    var items = visible(), cats = [], cur = "all";
    items.forEach(function (p) { if (p.category && !cats.some(function (c) { return c.id === p.category; })) cats.push({ id: p.category, label: p.categoryLabel || p.category }); });
    function draw() {
      var list = items.filter(function (p) { return cur === "all" || p.category === cur; });
      grid.innerHTML = list.length ? list.map(card).join("") : '<p class="empty">لا توجد منتجات في هذا التصنيف حاليًا.</p>';
      if (bar) Array.prototype.forEach.call(bar.querySelectorAll("button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-cat") === cur ? "true" : "false"); });
    }
    if (bar && cats.length > 1) {
      bar.innerHTML = '<button class="filter" type="button" data-cat="all">الكل</button>' + cats.map(function (c) { return '<button class="filter" type="button" data-cat="' + esc(c.id) + '">' + esc(c.label) + "</button>"; }).join("");
      bar.addEventListener("click", function (e) { var b = e.target.closest("button[data-cat]"); if (b) { cur = b.getAttribute("data-cat"); draw(); } });
    } else if (bar) { bar.hidden = true; }
    draw();
  }

  /* ---------- صفحة المنتج ---------- */
  function renderProduct() {
    var root = document.getElementById("product-root"); if (!root) return;
    var id = new URLSearchParams(location.search).get("id");
    var p = id ? byId(id) : null;
    if (!p || p.status === "hidden") {
      root.innerHTML = '<div class="panel"><h1>المنتج غير موجود</h1><p class="muted">قد يكون الرابط غير صحيح أو أن المنتج لم يعد معروضًا.</p><a class="btn btn-primary" href="products.html">العودة إلى المنتجات</a></div>';
      document.title = "المنتج غير موجود — " + S.storeName; return;
    }
    document.title = p.name + " — " + S.storeName;
    var md = document.querySelector('meta[name="description"]'); if (md) md.setAttribute("content", p.description);
    var og = document.querySelector('meta[property="og:title"]'); if (og) og.setAttribute("content", p.name + " — " + S.storeName);

    /* الحزمة: يحسب الموقع التوفير من أسعار المنتجات داخلها */
    var bundleHtml = "";
    if (p.includes && p.includes.length) {
      var inc = p.includes.map(byId).filter(Boolean), total = 0;
      inc.forEach(function (x) { total += Number(x.price) || 0; });
      if (inc.length === p.includes.length) {
        var save = total - Number(p.price);
        bundleHtml = '<div class="block"><h2>ماذا تضم الحزمة</h2><div class="bundle-box">' +
          inc.map(function (x) { return '<div class="bundle-row"><a href="product.html?id=' + encodeURIComponent(x.id) + '" dir="auto">' + esc(x.name) + "</a>" + priceHtml(x.price) + "</div>"; }).join("") +
          (save > 0
            ? '<div class="bundle-row bundle-total"><span>المجموع عند الشراء منفصلًا</span>' + priceHtml(total) + "</div>" +
              '<div class="bundle-row bundle-save"><strong>توفّر مع الحزمة</strong>' + priceHtml(save) + "</div>"
            : "") +
          "</div></div>";
      }
    }
    var facts = (p.details || []).map(function (d) { return '<div class="fact"><span>' + esc(d.label) + "</span><strong>" + esc(d.value) + "</strong></div>"; }).join("");
    var contents = (p.contents || []).map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("");

    var msg = orderMessage(p), main = mainChannel(msg), others = channels(msg).filter(function (c) { return !main || c.id !== main.id; });
    var action;
    if (p.status === "soon") {
      action = '<span class="btn btn-disabled btn-lg btn-block" aria-disabled="true">قريبًا</span><p class="note">هذا المنتج غير متاح للطلب بعد. تابعنا أو <a href="contact.html">تواصل معنا</a> للاستفسار.</p>';
    } else if (p.status === "paused") {
      action = '<span class="btn btn-disabled btn-lg btn-block" aria-disabled="true">غير متوفر حاليًا</span><p class="note">المنتج متوقف مؤقتًا. <a href="contact.html">تواصل معنا</a> للاستفسار.</p>';
    } else {
      action = '<a class="btn btn-primary btn-lg btn-block" ' + (main ? 'href="' + esc(main.url) + '" target="_blank" rel="noopener noreferrer"' : 'href="contact.html"') + ">اطلب الآن</a>" +
        (others.length ? '<div class="order-alt">أو عبر: ' + others.map(function (c) { return '<a class="btn btn-ghost btn-sm" href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer">' + c.label + "</a>"; }).join("") + "</div>" : "") +
        '<p class="note">لا يوجد دفع إلكتروني داخل الموقع. طريقة الدفع وتسليم الملفات تُنسَّق مع البائع، ويُرسَل المنتج بعد أن يؤكد البائع استلام الدفع.</p>' +
        (main ? "" : '<p class="callout">روابط التواصل لم تُضبط بعد. يضيفها صاحب المتجر من ملف settings.js.</p>') +
        '<details class="copy-msg"><summary>نسخ نص الطلب</summary><p id="order-text">' + esc(msg) + '</p><button class="btn btn-ghost btn-sm" id="copy-btn" type="button">نسخ</button></details>';
    }

    root.innerHTML =
      '<nav class="crumbs" aria-label="مسار الصفحة"><a href="index.html">الرئيسية</a><span>/</span><a href="products.html">المنتجات</a><span>/</span><span dir="auto">' + esc(p.name) + "</span></nav>" +
      '<div class="product-layout"><div class="product-main">' +
      '<div class="product-cover"><img src="' + esc(p.cover) + '" alt="' + esc("غلاف " + p.name) + '" width="800" height="500"></div>' +
      '<div class="tags" style="margin-top:18px"><span class="tag">' + typeLabel(p.type) + "</span>" + (p.categoryLabel ? '<span class="tag tag-soft">' + esc(p.categoryLabel) + "</span>" : "") + statusTag(p) + "</div>" +
      '<h1 dir="auto">' + esc(p.name) + "</h1>" +
      '<p class="lead">' + rich(p.description) + "</p>" +
      (facts ? '<div class="block"><h2>تفاصيل المنتج</h2><div class="facts">' + facts + "</div></div>" : "") +
      (contents ? '<div class="block"><h2>المحتويات</h2><ul class="list">' + contents + "</ul></div>" : "") +
      bundleHtml +
      "</div>" +
      '<aside class="order-card" aria-label="الطلب">' + priceHtml(p.price, true) + action + "</aside></div>";

    var cb = document.getElementById("copy-btn");
    if (cb) cb.addEventListener("click", function () {
      var el = document.getElementById("order-text"), txt = el.textContent;
      function done() { cb.textContent = "تم النسخ ✓"; }
      function fallback() { var r = document.createRange(); r.selectNodeContents(el); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); try { document.execCommand("copy"); done(); } catch (e) {} }
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, fallback); else fallback();
    });
  }

  /* ---------- التواصل ---------- */
  function renderContact() {
    var el = document.getElementById("channels"); if (!el) return;
    var list = channels("مرحبًا، أريد الاستفسار عن منتجات The Edit Lab.");
    var html = list.map(function (c) { return '<a class="channel" href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer">' + c.label + "<span>" + esc(c.hint) + "</span></a>"; }).join("");
    if (str(C.email)) html += '<a class="channel" href="mailto:' + esc(str(C.email)) + '">البريد الإلكتروني<span>' + esc(str(C.email)) + "</span></a>";
    el.innerHTML = html || '<p class="callout">لم تُضبط روابط التواصل بعد. يضيفها صاحب المتجر من ملف settings.js.</p>';
    var hrs = document.getElementById("hours");
    if (hrs) { if (str(C.responseHours)) hrs.textContent = "أوقات الرد: " + str(C.responseHours); else hrs.hidden = true; }
  }

  /* ---------- الأسئلة الشائعة ---------- */
  function faqHtml(list) { return list.map(function (x) { return "<details><summary>" + esc(x.q) + "</summary><p>" + esc(x.a) + "</p></details>"; }).join(""); }
  function renderFaq() {
    var el = document.getElementById("faq-list"); if (el) el.innerHTML = faqHtml(S.faq || []);
    var t = document.getElementById("faq-teaser"); if (t) t.innerHTML = faqHtml((S.faq || []).slice(0, 3));
  }

  /* ---------- السياسات ---------- */
  function renderPolicy() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-seller]"), function (n) { n.textContent = S.sellerName; });
    Array.prototype.forEach.call(document.querySelectorAll("[data-updated]"), function (n) { n.textContent = S.policiesUpdated; });
    var b = document.getElementById("policy-banner");
    if (b) {
      if (S.policiesApproved === true) b.hidden = true;
      else b.innerHTML = "<strong>مسودة قيد المراجعة.</strong> هذه الصفحة صياغة مبدئية عامة، وليست استشارة قانونية ولا تضمن الامتثال للقوانين المعمول بها. العبارات المظللة تنتظر قرار صاحب المتجر.";
    }
  }

  renderChrome(); renderHome(); renderProducts(); renderProduct(); renderContact(); renderFaq(); renderPolicy();
})();
