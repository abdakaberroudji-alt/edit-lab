/* ============================================================
   المنتجات — لتعديل منتج: غيّر النص الذي بين علامتي الاقتباس.
   لإضافة منتج: انسخ كتلة كاملة من { إلى } (مع الفاصلة بعدها)
   والصقها بعد آخر منتج، ثم غيّر القيم. الشرح الكامل في README.md.

   الحقول:
   id          معرّف فريد بحروف إنجليزية صغيرة وشرطات (يظهر في الرابط، لا تغيّره بعد النشر).
   status      "available" متوفر | "soon" قريبًا | "paused" غير متوفر حاليًا | "hidden" مخفي
   featured    true ليظهر في الصفحة الرئيسية، أو false
   category    "courses" أو أي اسم تصنيف تريده (يظهر فلتر التصنيفات تلقائيًا إن وُجد أكثر من تصنيف)
   categoryLabel  اسم التصنيف بالعربية
   type        "audio" أو "video" أو "bundle" (يحدد شكل الشارة فقط)
   price       السعر بالدينار الجزائري، رقم فقط
   cover       اسم ملف الغلاف (ضعه بجانب باقي الملفات)
   includes    للحزم فقط: قائمة id المنتجات داخل الحزمة. يحسب الموقع التوفير تلقائيًا.
   details     معلومات مؤكدة فقط، مثل { label: "عدد الأجزاء", value: "..." }. اتركها [] إن لم تعرف.
   contents    قائمة ملفات أو دروس مؤكدة فقط. اتركها [] إن لم تعرف.

   لا تكتب في هذا الملف أي رابط تنزيل. الملفات تُرسل للزبون بعد الدفع في محادثة خاصة.
   ============================================================ */
window.PRODUCTS = [
  {
    id: "english-audio-masterclass",
    status: "available",
    featured: true,
    category: "courses",
    categoryLabel: "دورات تعليمية",
    type: "audio",
    name: "English Audio Masterclass",
    tagline: "تسجيلات صوتية لتعلّم الإنجليزية",
    description: "تسجيلات صوتية طويلة ومفصّلة لتعلّم اللغة الإنجليزية.",
    price: 2900,
    cover: "cover-audio.svg",
    includes: [],
    details: [],
    contents: []
  },
  {
    id: "english-video-course",
    status: "available",
    featured: true,
    category: "courses",
    categoryLabel: "دورات تعليمية",
    type: "video",
    name: "English Video Course",
    tagline: "دورة فيديو تبدأ من الأساسيات",
    description: "دورة لتعلّم اللغة الإنجليزية تبدأ من الأساسيات، وتتكون من أكثر من 23 جزءًا.",
    price: 3500,
    cover: "cover-video.svg",
    includes: [],
    details: [
      { label: "عدد الأجزاء", value: "أكثر من 23 جزءًا" },
      { label: "نقطة البداية", value: "من الأساسيات" }
    ],
    contents: []
  },
  {
    id: "english-master-bundle",
    status: "available",
    featured: true,
    category: "courses",
    categoryLabel: "دورات تعليمية",
    type: "bundle",
    name: "English Master Bundle",
    tagline: "الصوت والفيديو في حزمة واحدة",
    description: "حزمة تجمع بين كورس التسجيلات الصوتية، وهو English Audio Masterclass، ودورة الفيديو، وهي English Video Course.",
    price: 5500,
    cover: "cover-bundle.svg",
    includes: ["english-audio-masterclass", "english-video-course"],
    details: [],
    contents: []
  }
];
